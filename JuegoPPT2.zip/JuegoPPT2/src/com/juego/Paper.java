package com.juego;

class Paper extends Jugada {
    @Override
    boolean jugarContra(Jugada otraJugada) {
        return !otraJugada.resultadoContraPaper();
    }

    @Override
    boolean resultadoContraRock() {
        return true;
    }

    @Override
    boolean resultadoContraScissors() {
        return false;
    }

    @Override
    boolean resultadoContraSpock() {
        return false;
    }

    @Override
    boolean resultadoContraLizard() {
        return false;
    }
}
