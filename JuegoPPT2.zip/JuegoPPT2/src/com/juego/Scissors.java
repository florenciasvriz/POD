package com.juego;

class Scissors extends Jugada {
    @Override
    boolean jugarContra(Jugada otraJugada) {
        return !otraJugada.resultadoContraScissors();
    }

    @Override
    boolean resultadoContraPaper() {
        return true;
    }

    @Override
    boolean resultadoContraRock() {
        return false;
    }

    @Override
    boolean resultadoContraSpock() {
        return false;
    }

    @Override
    boolean resultadoContraLizard() {
        return true;
    }
}
