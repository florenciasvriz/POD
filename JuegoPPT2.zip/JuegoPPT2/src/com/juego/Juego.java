package com.juego;

public class Juego {
    public static void main(String[] args) {
        Jugada piedra = new Rock();
        Jugada papel = new Paper();
        Jugada tijera = new Scissors();
        Jugada lagarto = new Lizard();
        Jugada spock = new Spock();

        System.out.println("Papel contra Piedra: " + papel.jugarContra(piedra)); // true
        System.out.println("Piedra contra Tijera: " + piedra.jugarContra(tijera)); // true
        System.out.println("Tijera contra Papel: " + tijera.jugarContra(papel)); // true
        System.out.println("Spock contra Tijera: " + spock.jugarContra(tijera)); // true
        System.out.println("Lagarto contra Papel: " + lagarto.jugarContra(papel)); // true
    }
}

