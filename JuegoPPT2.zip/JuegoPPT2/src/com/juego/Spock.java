package com.juego;

class Spock extends Jugada {
    @Override
    boolean jugarContra(Jugada otraJugada) {
        return !otraJugada.resultadoContraSpock();
    }

    @Override
    boolean resultadoContraScissors() {
        return true;
    }

    @Override
    boolean resultadoContraRock() {
        return true;
    }

    @Override
    boolean resultadoContraPaper() {
        return false;
    }

    @Override
    boolean resultadoContraLizard() {
        return false;
    }
}
