package com.juego;

abstract class Jugada {
    abstract boolean jugarContra(Jugada otraJugada);

    boolean resultadoContraRock() {
        return false;
    }

    boolean resultadoContraPaper() {
        return false;
    }

    boolean resultadoContraScissors() {
        return false;
    }

    boolean resultadoContraSpock() {
        return false;
    }

    boolean resultadoContraLizard() {
        return false;
    }
}
