package com.juego;

class Rock extends Jugada {
    @Override
    boolean jugarContra(Jugada otraJugada) {
        return !otraJugada.resultadoContraRock();
    }

    @Override
    boolean resultadoContraPaper() {
        return false;
    }

    @Override
    boolean resultadoContraScissors() {
        return true;
    }

    @Override
    boolean resultadoContraSpock() {
        return false;
    }

    @Override
    boolean resultadoContraLizard() {
        return true;
    }
}
