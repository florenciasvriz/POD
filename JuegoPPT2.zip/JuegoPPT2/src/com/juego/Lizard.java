package com.juego;

class Lizard extends Jugada {
    @Override
    boolean jugarContra(Jugada otraJugada) {
        return !otraJugada.resultadoContraLizard();
    }

    @Override
    boolean resultadoContraPaper() {
        return true;
    }

    @Override
    boolean resultadoContraSpock() {
        return true;
    }

    @Override
    boolean resultadoContraRock() {
        return false;
    }

    @Override
    boolean resultadoContraScissors() {
        return false;
    }
}
